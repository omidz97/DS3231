#include "stm32f1xx_hal.h"
#define  LCD_GPIO  GPIOA
/* Connections between LCD and STM32F373cct6  */
#define LCD_RS          GPIO_PIN_1
#define LCD_RW          GPIO_PIN_2
#define  LCD_EN          GPIO_PIN_3
#define  LCD_D4          GPIO_PIN_4
#define  LCD_D5          GPIO_PIN_5
#define  LCD_D6                GPIO_PIN_6
#define  LCD_D7          GPIO_PIN_7
#define  LCD_PORT        LCD_GPIO        // Port that is connected the LCD (current port is PORT B)
#define  LCD_D_ALL     (GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6| GPIO_PIN_7)
 
 
 
 
void delay_ms(int ms);
void delay_us(int us);
unsigned char LCD_ReadByte(void);
void LCD_SendByte(unsigned char cmd);
void LCD_SendCmd (unsigned char cmd);
void LCD_SendData(char data);
void LCD_SendText(char x,char  y,char *text);
void LCD_GoTo (unsigned char line, unsigned char column);
void LCD_Clear (void);
void LCD_Init (void);
